import { GuiaSonoBebe } from "@/components/guia-sono-bebe"

export default function GuiaSonoBebeePage() {
  return (
    <main className="min-h-screen bg-background">
      <GuiaSonoBebe />
    </main>
  )
}
